Sovereign Stock Token — SOST
Brand Kit v3.2 (14 November 2026)
https://sostcore.com/brand/

Name: Sovereign Stock Token    Ticker: SOST
Write it as: Sovereign Stock Token — SOST

Current official logo: gold Sigma in its multicolour orbit, no outer ring -> primary/, icons/
Legacy logo: historical use only (plain red Sigma) -> legacy/

primary/  official logo: native-resolution file (552 px), HD master and 2048/1024 px
          (x4 super-resolution UPSCALES of the approved artwork, not native originals), 512-32 px;
          transparent (clean alpha edge, no dark outline on light backgrounds) and on black
icons/    circle-safe square token icons 1024-32 px (exchange listings, wallets), dark avatars, favicon set, social card
legacy/   legacy red Sigma - historical use only, never as the current logo
guide/    SOST_Brand_Guide.pdf / .md - colours, clear space, minimum size, correct and incorrect use
preview/  logo on dark and on light, circle crop, clear space, minimum size, legacy preview

SHA256SUMS.txt lists the SHA-256 of every file in this kit.
